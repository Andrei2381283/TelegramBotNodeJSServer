const express = require("express");
const fs = require("fs");

const router = express.Router();

router.all("/read", (req,res) => {
    res.send(fs.readFileSync(__dirname + "/../log.log").toString());
});

module.exports = router;